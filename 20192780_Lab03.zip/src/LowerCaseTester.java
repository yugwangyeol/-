
public class LowerCaseTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String greeting ="Hello, World!";
		int n = greeting.length();
		
		String river = "Mississippi";
		String bigRiver = river.toUpperCase();
		
		String testString = "This is a Test";
		String smallTestString = testString.toLowerCase();
		
		System.out.println(smallTestString);
		
		String bigTestString = smallTestString.toUpperCase();
		System.out.println(bigTestString);

	}

}
