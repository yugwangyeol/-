import java.util.Scanner;

public class BasicI0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdin = new Scanner(System.in);
		
		System.out.print("Enter your name: ");
		String name = stdin.nextLine();
		System.out.print("Enter your age: ");
		int years = stdin.nextInt();
		System.out.print("Enter your height: ");
		int height = stdin.nextInt();
		
		System.out.println("your name is "+name);
		System.out.println("your age is "+years);
		System.out.println("your day is "+years*365);
		System.out.println("2020�� 10�� 03�� ���� "+name+"("+years+")"+"�� Ű�� "+height+"cm �Դϴ�.");
		

	}

}
